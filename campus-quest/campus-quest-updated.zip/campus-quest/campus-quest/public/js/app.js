/* Campus Quest - page logic: registration, game box (80% of the page), timer, score at the top, saving the result */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const fmt = (s) => String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  let player = null, game = null, tick = null, finished = false;

  function toast(msg, kind, ms) {
    const t = $('toast'); t.textContent = msg; t.className = 'toast ' + (kind || ''); 
    clearTimeout(toast.h); if (ms !== 0) toast.h = setTimeout(() => t.classList.add('hidden'), ms || 3500);
  }
  async function post(url, body) {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    let j = {}; try { j = await r.json(); } catch (e) { /* ignore */ }
    if (!r.ok) { const e = new Error(j.error || 'Something went wrong.'); e.status = r.status; e.data = j; throw e; }
    return j;
  }

  /* ---- the game box always covers 80% of the free page area ---- */
  function layoutStage() {
    const m = $('main').getBoundingClientRect(), s = $('stage');
    const bw = m.width * 0.8, bh = m.height * 0.8;
    const w = Math.max(320, Math.min(bw, bh * 16 / 9)), h = w * 9 / 16;
    s.style.width = Math.round(w) + 'px'; s.style.height = Math.round(h) + 'px';
  }
  window.addEventListener('resize', layoutStage);

  /* ---- team suggestions ---- */
  fetch('/api/teams').then((r) => r.json()).then((j) => {
    $('teamList').innerHTML = '';
    (j.teams || []).forEach((t) => { const o = document.createElement('option'); o.value = t; $('teamList').appendChild(o); });
  }).catch(() => {});
  try { const old = JSON.parse(localStorage.getItem('cq_last') || '{}'); $('fName').value = old.name || ''; $('fRoll').value = old.rollNo || ''; $('fTeam').value = old.team || ''; } catch (e) { /* ignore */ }

  /* ---- registration ---- */
  $('regForm').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    $('regErr').textContent = ''; $('regBtn').disabled = true;
    try {
      const j = await post('/api/register', { name: $('fName').value, rollNo: $('fRoll').value, team: $('fTeam').value });
      player = j.participant;
      localStorage.setItem('cq_last', JSON.stringify({ name: $('fName').value, rollNo: $('fRoll').value, team: $('fTeam').value }));
      beginGame();
    } catch (e) {
      $('regErr').textContent = e.message === 'Failed to fetch' ? 'Cannot reach the server. Check the network and try again.' : e.message;
    } finally { $('regBtn').disabled = false; }
  });

  async function beginGame() {
    $('regCard').classList.add('hidden'); $('stage').classList.remove('hidden');
    $('pName').textContent = player.name; $('pTeam').textContent = player.team; $('chipPlayer').classList.remove('hidden');
    $('chipTime').classList.remove('hidden');
    layoutStage();
    try {
      game = await window.CampusGame($('gameCanvas'), { onStart, onFinish, version: '1' });
      $('loading').classList.add('hidden');
      $('gameCanvas').focus();
    } catch (e) {
      $('loading').textContent = 'Could not start the game: ' + e.message;
    }
  }

  /* ---- messages from the game ---- */
  let playing = false;
  function onStart() {
    playing = true;
    post('/api/start', { id: player.id }).catch(() => {});
    clearInterval(tick);
    tick = setInterval(() => { if (!finished && game) $('timer').textContent = fmt(game.elapsed()); }, 250);
  }
  function onFinish(r) {
    finished = true; clearInterval(tick);
    $('timer').textContent = fmt(r.seconds);
    $('sScore').textContent = r.score; $('sTime').textContent = fmt(r.seconds);
    $('sDetail').textContent = '· ' + r.right + ' right, ' + r.wrong + ' wrong';
    $('chipScore').classList.remove('hidden'); $('chipTime').classList.add('hidden');
    $('foot').innerHTML = 'Your result is final. Thank you for playing! &nbsp;·&nbsp; <a href="/admin">Staff login</a>';
    save(r, 0);
  }
  async function save(r, attempt) {
    try {
      const j = await post('/api/submit', { id: player.id, right: r.right, wrong: r.wrong, seconds: r.seconds });
      const res = j.result;
      $('sScore').textContent = res.score; $('sTime').textContent = fmt(res.seconds);
      toast('Result saved ✓', 'ok');
    } catch (e) {
      if (e.status === 409) { toast('Result was already saved.', 'ok'); return; }
      if (attempt < 20) { toast('Could not save the result yet - retrying…', 'bad', 4000); setTimeout(() => save(r, attempt + 1), 4000); }
      else toast('Could not save the result. Tell your staff member.', 'bad', 0);
    }
  }
})();
