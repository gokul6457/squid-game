/* Campus Quest - admin portal (password protected; data comes from /api/admin/data) */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const fmt = (s) => String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    let token = sessionStorage.getItem('cq_admin') || '', data = null, tab = 'ind', timer = null;

  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }

  function table(cols, rows) {
    const box = $('tableBox'); box.innerHTML = '';
    if (!rows.length) { box.appendChild(el('div', 'empty', 'Nothing here yet.')); return; }
    const t = el('table'), th = el('thead'), hr = el('tr');
    cols.forEach((c) => hr.appendChild(el('th', c.num ? 'num' : '', c.h)));
    th.appendChild(hr); t.appendChild(th);
    const tb = el('tbody');
    rows.forEach((r) => {
      const tr = el('tr');
      cols.forEach((c) => {
        const td = el('td', c.num ? 'num' : '');
        const v = c.get(r);
        if (c.pill) { td.appendChild(el('span', 'pill ' + v, v)); } else { td.textContent = v; }
        if (c.cls && c.cls(r)) td.className += ' ' + c.cls(r);
        tr.appendChild(td);
      });
      tb.appendChild(tr);
    });
    t.appendChild(tb); box.appendChild(t);
  }

  const dash = (r, v) => r.done ? v : '—';
  const VIEWS = {
    ind: { rows: () => data.individuals, cols: [
      { h: 'Rank', num: true, get: (r) => r.rank == null ? '—' : r.rank, cls: (r) => r.rank === 1 ? 'rank1' : '' },
      { h: 'Name', get: (r) => r.name }, { h: 'Register no.', get: (r) => r.rollNo }, { h: 'Team', get: (r) => r.team },
      { h: 'Score / 100', num: true, get: (r) => dash(r, r.score) }, { h: 'Right', num: true, get: (r) => dash(r, r.right) },
      { h: 'Wrong', num: true, get: (r) => dash(r, r.wrong) }, { h: 'Time taken', num: true, get: (r) => dash(r, fmt(r.seconds)) }] },
    team: { rows: () => data.teams, cols: [
      { h: 'Rank', num: true, get: (r) => r.rank == null ? '—' : r.rank, cls: (r) => r.rank === 1 ? 'rank1' : '' },
      { h: 'Team', get: (r) => r.team }, { h: 'Players', num: true, get: (r) => r.players },
      { h: 'Score', num: true, get: (r) => r.finished ? r.score : '—' }, { h: 'Right', num: true, get: (r) => r.finished ? r.right : '—' },
      { h: 'Wrong', num: true, get: (r) => r.finished ? r.wrong : '—' }, { h: 'Total time', num: true, get: (r) => r.finished ? fmt(r.seconds) : '—' }] },
  };

  function render() {
    if (!data) return;
    $('updTime').textContent = new Date(data.generatedAt).toLocaleTimeString(); $('updated').classList.remove('hidden');
    const v = VIEWS[tab]; table(v.cols, v.rows());
    document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  }

  async function load() {
    try {
      const r = await fetch('/api/admin/data', { headers: { Authorization: 'Bearer ' + token }, cache: 'no-store' });
      if (r.status === 401) return showLogin();
      data = await r.json(); render();
    } catch (e) { /* server busy: try again on the next tick */ }
  }
  function showDash() {
    $('loginBox').classList.add('hidden'); $('dash').classList.remove('hidden'); $('logout').classList.remove('hidden');
    load(); clearInterval(timer); timer = setInterval(load, 5000);
  }
  function showLogin() {
    clearInterval(timer); token = ''; sessionStorage.removeItem('cq_admin');
    $('dash').classList.add('hidden'); $('logout').classList.add('hidden'); $('updated').classList.add('hidden'); $('loginBox').classList.remove('hidden');
    $('pw').value = ''; $('pw').focus();
  }

  $('loginForm').addEventListener('submit', async (ev) => {
    ev.preventDefault(); $('loginErr').textContent = ''; $('loginBtn').disabled = true;
    try {
      const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: $('pw').value }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || 'Login failed.');
      token = j.token; sessionStorage.setItem('cq_admin', token); showDash();
    } catch (e) { $('loginErr').textContent = e.message === 'Failed to fetch' ? 'Cannot reach the server.' : e.message; }
    finally { $('loginBtn').disabled = false; }
  });
  $('logout').addEventListener('click', async () => {
    try { await fetch('/api/admin/logout', { method: 'POST', headers: { Authorization: 'Bearer ' + token } }); } catch (e) { /* ignore */ }
    showLogin();
  });
  document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.tab; render(); }));

  $('csv').addEventListener('click', () => {
    if (!data) return;
    const v = VIEWS[tab], q = (s) => '"' + String(s).replace(/"/g, '""') + '"';
    const lines = [v.cols.map((c) => q(c.h)).join(',')].concat(v.rows().map((r) => v.cols.map((c) => q(c.get(r))).join(',')));
    const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = 'campus-quest-' + ({ ind: 'individual-results', team: 'team-results' })[tab] + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
  });

  if (token) showDash();
})();
