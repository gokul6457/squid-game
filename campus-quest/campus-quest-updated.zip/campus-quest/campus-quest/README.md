# CAMPUS QUEST - website + admin portal

The campus game now runs **inside a website**. Students register, play in a box that covers 80% of the page,
and see their **score and finishing time at the top**. Staff use a **separate password-protected Admin Portal**.

## 1. Run it (one computer acts as the server)
1. Install **Node.js** (version 16 or newer) from https://nodejs.org - nothing else is needed.
2. Double-click **start.bat** (Windows) or run `node server.js` (Mac / Linux) in this folder.
3. The window prints the addresses:
   * Game for students  ->  `http://<this-computer's-IP>:3000`   (the line "On the lab network")
   * Admin portal       ->  `http://<this-computer's-IP>:3000/admin`
4. Students open the game address in **Chrome / Edge / Firefox** on their lab PCs (same network). Keep the server window open.

## 2. Admin password  (change it before the event!)
Open **config.json** and change `"adminPassword"` (default is `admin@123`), then restart the server.
Staff / student heads go to `/admin`, enter the password, and see:
* **Individual results** - every player: rank, **score out of 100, right components, wrong components, total time taken**
* **Team results** - for every team: **total score, total right, total wrong, total time** of its players
* **Download CSV** button for the tab you are looking at. The page refreshes itself every 5 seconds.

## 3. How a student plays
Register (name, register number, team) -> read the mission -> press START -> collect letters -> submit at the
Component Submission Hub. The timer starts when START is pressed and stops at submission.
* Each **correct** component = **+10**, each **wrong** one = **-10** (never below 0). Score is out of **100**.
* The "website created" percentage on the result scroll = 10% per correct component submitted.
* After submitting, the result is final: the player is frozen, no key works, and the score + time stay at the top of the page.
* **One attempt per register number.** If someone closes the browser before finishing, they can register again with the
  same register number and play again from the start. A register number that has finished cannot play again.

## 4. Ranking rules
* Individuals: higher score first; if equal, the **shorter time** wins. Players who have not finished show dashes.
* Teams: the team's score, right, wrong and time are the **totals of its finished players**; ranked by total score, then shorter total time.
* The server checks the finishing time against its own clock, so a changed browser clock cannot fake a fast time.

## 5. Where is the data? How do I reset?
All results are in `data/db.json` (created automatically). To start a fresh event: stop the server, delete
`data/db.json`, start again. Copy the file somewhere safe if you want a backup.

## 6. Folder guide
```
server.js        the web server (registrations, results, admin login)
config.json      admin password
start.bat/.sh    start helpers
public/          the website: index.html (game page), admin.html (admin portal), js/, game/game.wasm (the game)
game-src/        the game's source code (main.c) and the tools that turn it into game.wasm
tests/           a self-test for the server
```
### Changing the game later (for developers)
`game-src/main.c` is the C game (it still builds as the desktop SDL3 game). After editing it, rebuild the web version:
`sudo apt install clang lld wasi-libc libclang-rt-18-dev-wasm32` then `game-src/build.sh` -> updates `public/game/game.wasm`.
