@echo off
title Campus Quest server
cd /d "%~dp0"
echo Starting Campus Quest... (keep this window open while students play)
start "" http://localhost:3000
node server.js
pause
