// Quick self-test of the server.  Run with a FRESH server:  ADMIN_PASSWORD=secret123 node server.js   then   node tests/api-test.js
const B = process.env.BASE || 'http://localhost:3000'; let fails = 0;
const ok = (c, m) => { if (!c) { console.log('FAIL:', m); fails++; } else console.log('ok  :', m); };
async function post(u, b, h) { const r = await fetch(B + u, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, h || {}), body: JSON.stringify(b) }); return [r.status, await r.json()]; }
(async () => {
  let [s, j] = await post('/api/register', { name: 'A', rollNo: '1', team: 'x' }); ok(s === 400, 'short name rejected');
  [s, j] = await post('/api/register', { name: 'Anitha K', rollNo: '21CS001', team: 'Red Hawks' }); ok(s === 200 && j.participant.id, 'register ok'); const a = j.participant;
  [s, j] = await post('/api/register', { name: 'Bala S', rollNo: '21CS002', team: 'red hawks' }); ok(s === 200 && j.participant.team === 'Red Hawks', 'team name matched case-insensitively'); const b = j.participant;
  [s, j] = await post('/api/register', { name: 'Charu M', rollNo: '21CS003', team: 'Blue Owls' }); const c = j.participant;
  [s, j] = await post('/api/register', { name: 'Anitha K', rollNo: '21cs001', team: 'Red Hawks' }); ok(s === 200 && j.resumed && j.participant.id === a.id, 'same register no resumes (not finished)');
  [s, j] = await post('/api/register', { name: '<b>X</b> Y', rollNo: '21CS004', team: 'Blue Owls' }); ok(s === 200 && !/[<>]/.test(j.participant.name), 'html stripped from name');
  await post('/api/start', { id: a.id }); await post('/api/start', { id: b.id }); await post('/api/start', { id: c.id });
  [s, j] = await post('/api/submit', { id: a.id, right: 9, wrong: 2, seconds: 0 });
  ok(s === 200 && j.result.score === 70, 'score = (9-2)*10 = 70 -> ' + JSON.stringify(j.result));
  [s, j] = await post('/api/submit', { id: a.id, right: 10, wrong: 0, seconds: 5 }); ok(s === 409, 'cannot submit twice');
  [s, j] = await post('/api/register', { name: 'Anitha K', rollNo: '21CS001', team: 'Red Hawks' }); ok(s === 409, 'finished register no cannot play again');
  await new Promise((r) => setTimeout(r, 1200));
  [s, j] = await post('/api/submit', { id: b.id, right: 10, wrong: 0, seconds: 1 }); ok(s === 200 && j.result.score === 100, 'perfect = 100');
  [s, j] = await post('/api/submit', { id: c.id, right: 1, wrong: 5, seconds: 3 }); ok(s === 200 && j.result.score === 0, 'negative score floors at 0');
  [s, j] = await post('/api/submit', { id: 'nope', right: 1, wrong: 0, seconds: 3 }); ok(s === 404, 'unknown id rejected');
  let r = await fetch(B + '/api/admin/data'); ok(r.status === 401, 'admin data needs login');
  [s, j] = await post('/api/admin/login', { password: 'wrong' }); ok(s === 401, 'wrong password rejected');
  [s, j] = await post('/api/admin/login', { password: 'secret123' }); ok(s === 200 && j.token, 'right password accepted'); const tok = j.token;
  r = await fetch(B + '/api/admin/data', { headers: { Authorization: 'Bearer ' + tok } }); const d = await r.json(); ok(r.status === 200, 'admin data with token');
  console.log(' individuals', d.individuals.map((x) => (x.rank || '-') + '.' + x.name + ' ' + (x.done ? x.score + '/' + x.right + 'R/' + x.wrong + 'W ' + x.seconds + 's' : 'not finished')).join(' | '));
  console.log(' teams', d.teams.map((t) => (t.rank || '-') + '.' + t.team + ' score ' + t.score + ' right ' + t.right + ' wrong ' + t.wrong + ' time ' + t.seconds + 's players ' + t.players).join(' | '));
  ok(d.individuals[0].name === 'Bala S' && d.individuals[1].name === 'Anitha K', 'individuals ranked by score');
  ok(d.individuals[d.individuals.length - 1].done === false && d.individuals[d.individuals.length - 1].rank === null, 'unfinished players listed last, no rank');
  const rh = d.teams.find((t) => t.team === 'Red Hawks');
  ok(rh.rank === 1 && rh.score === 170 && rh.right === 19 && rh.wrong === 2 && rh.players === 2, 'team totals: score 170, right 19, wrong 2');
  ok(!('summary' in d) && !('registeredAt' in (d.individuals[0] || {})), 'no registered/started/finished data sent to the portal');
  for (let i = 0; i < 6; i++) await post('/api/admin/login', { password: 'bad' + i });
  [s, j] = await post('/api/admin/login', { password: 'secret123' }); ok(s === 429, 'login is rate-limited after repeated wrong passwords');
  console.log(fails ? 'FAILED ' + fails : 'ALL API TESTS PASSED'); process.exit(fails ? 1 : 0);
})();
