/*
 * Campus Quest server - no extra packages needed, only Node.js (v16 or newer).
 *   Start:   node server.js            (then open http://localhost:3000)
 *   Players: http://<this-computer-ip>:3000        Admin portal: http://<this-computer-ip>:3000/admin
 * Data is kept in data/db.json.  Admin password: config.json  ("adminPassword")  or the ADMIN_PASSWORD environment variable.
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const PORT = parseInt(process.env.PORT || '3000', 10);
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

let config = {};
try { config = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8')); } catch (e) { /* optional */ }
const ADMIN_PASSWORD = String(process.env.ADMIN_PASSWORD || config.adminPassword || 'admin@123');
const DEFAULT_PASSWORD = ADMIN_PASSWORD === 'admin@123';

/* ---------------- storage ---------------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
let db = { participants: [] };
try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) { /* first start */ }
if (!Array.isArray(db.participants)) db.participants = [];
let saving = false, dirty = false;
function save() {
  dirty = true;
  if (saving) return;
  saving = true; dirty = false;
  const tmp = DB_FILE + '.tmp';
  fs.writeFile(tmp, JSON.stringify(db, null, 1), (err) => {
    if (!err) fs.rename(tmp, DB_FILE, () => { saving = false; if (dirty) save(); });
    else { saving = false; console.error('could not save data:', err.message); }
  });
}

/* ---------------- helpers ---------------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.wasm': 'application/wasm', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' };

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 20000) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(new Error('bad json')); } });
    req.on('error', reject);
  });
}
const clean = (s, max) => String(s == null ? '' : s).replace(/[\u0000-\u001f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
const norm = (s) => s.toLowerCase();
function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest(), hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}
function publicView(p) { return { id: p.id, name: p.name, rollNo: p.rollNo, team: p.team }; }

/* ---------------- admin sessions ---------------- */
const sessions = new Map();               // token -> expiry
const failures = new Map();               // ip -> [timestamps]
function clientIp(req) { return req.socket.remoteAddress || '?'; }
function tooManyFailures(ip) {
  const now = Date.now(), list = (failures.get(ip) || []).filter((t) => now - t < 5 * 60 * 1000);
  failures.set(ip, list); return list.length >= 5;
}
function adminOk(req) {
  const h = req.headers['authorization'] || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  const exp = sessions.get(token);
  if (!exp) return false;
  if (exp < Date.now()) { sessions.delete(token); return false; }
  return true;
}

/* ---------------- results ---------------- */
function adminData() {
  const all = db.participants;
  /* every player with score, right, wrong and total time (players who have not finished show dashes) */
  const individuals = all.map((p) => ({ name: p.name, rollNo: p.rollNo, team: p.team, done: !!p.finishedAt,
    score: p.score || 0, right: p.right || 0, wrong: p.wrong || 0, seconds: p.seconds || 0 }));
  individuals.sort((a, b) => (b.done - a.done) || b.score - a.score || a.seconds - b.seconds || a.name.localeCompare(b.name));
  let ri = 0; individuals.forEach((x) => { x.rank = x.done ? ++ri : null; });
  /* teams = totals of all their finished players */
  const groups = new Map();
  for (const x of individuals) {
    const k = norm(x.team);
    if (!groups.has(k)) groups.set(k, { team: x.team, members: [] });
    groups.get(k).members.push(x);
  }
  const teams = [];
  for (const g of groups.values()) {
    const fin = g.members.filter((m) => m.done);
    teams.push({ team: g.team, players: g.members.length, finished: fin.length,
      score: fin.reduce((t, m) => t + m.score, 0), right: fin.reduce((t, m) => t + m.right, 0),
      wrong: fin.reduce((t, m) => t + m.wrong, 0), seconds: fin.reduce((t, m) => t + m.seconds, 0) });
  }
  teams.sort((a, b) => (b.finished > 0) - (a.finished > 0) || b.score - a.score || a.seconds - b.seconds || a.team.localeCompare(b.team));
  let rt = 0; teams.forEach((t) => { t.rank = t.finished ? ++rt : null; });
  return { generatedAt: Date.now(), individuals, teams };
}

/* ---------------- API ---------------- */
async function api(req, res, url) {
  const route = req.method + ' ' + url.pathname;
  try {
    if (route === 'GET /api/teams') {
      return send(res, 200, { teams: [...new Set(db.participants.map((p) => p.team))].sort() });
    }
    if (route === 'POST /api/register') {
      const b = await readBody(req);
      const name = clean(b.name, 60), rollNo = clean(b.rollNo, 30), teamIn = clean(b.team, 40);
      if (name.length < 2) return send(res, 400, { error: 'Please enter your full name.' });
      if (!rollNo) return send(res, 400, { error: 'Please enter your register number.' });
      if (!teamIn) return send(res, 400, { error: 'Please enter your team name.' });
      const existingTeam = db.participants.find((p) => norm(p.team) === norm(teamIn));
      const team = existingTeam ? existingTeam.team : teamIn;
      const old = db.participants.find((p) => norm(p.rollNo) === norm(rollNo));
      if (old) {
        if (old.finishedAt) return send(res, 409, { error: 'This register number has already completed the game. Each student can play once.' });
        return send(res, 200, { participant: publicView(old), resumed: true });       // not finished yet: let them continue
      }
      const p = { id: crypto.randomBytes(12).toString('hex'), name, rollNo, team, registeredAt: Date.now(), startedAt: null, finishedAt: null, score: 0, right: 0, wrong: 0, seconds: 0 };
      db.participants.push(p); save();
      return send(res, 200, { participant: publicView(p) });
    }
    if (route === 'POST /api/start') {
      const b = await readBody(req);
      const p = db.participants.find((x) => x.id === b.id);
      if (!p) return send(res, 404, { error: 'Unknown player.' });
      if (p.finishedAt) return send(res, 409, { error: 'Already finished.' });
      p.startedAt = Date.now(); save();
      return send(res, 200, { ok: true });
    }
    if (route === 'POST /api/submit') {
      const b = await readBody(req);
      const p = db.participants.find((x) => x.id === b.id);
      if (!p) return send(res, 404, { error: 'Unknown player.' });
      if (p.finishedAt) return send(res, 409, { error: 'Result already saved.', result: { score: p.score, right: p.right, wrong: p.wrong, seconds: p.seconds } });
      const right = Math.floor(Number(b.right)), wrong = Math.floor(Number(b.wrong)), clientSecs = Math.floor(Number(b.seconds));
      if (!(right >= 0 && right <= 10 && wrong >= 0 && wrong <= 10 && clientSecs >= 0)) return send(res, 400, { error: 'Invalid result.' });
      let seconds = Math.min(clientSecs, 86400);
      if (p.startedAt) {                                    // do not trust the browser's clock too much
        const serverSecs = Math.round((Date.now() - p.startedAt) / 1000);
        if (Math.abs(serverSecs - seconds) > 10) seconds = serverSecs;
      }
      p.right = right; p.wrong = wrong; p.score = Math.max(0, (right - wrong) * 10); p.seconds = seconds; p.finishedAt = Date.now();
      save();
      return send(res, 200, { ok: true, result: { score: p.score, right: p.right, wrong: p.wrong, seconds: p.seconds } });
    }
    if (route === 'POST /api/admin/login') {
      const ip = clientIp(req);
      if (tooManyFailures(ip)) return send(res, 429, { error: 'Too many wrong attempts. Please wait 5 minutes.' });
      const b = await readBody(req);
      if (!safeEqual(b.password || '', ADMIN_PASSWORD)) {
        failures.get(ip).push(Date.now());
        return send(res, 401, { error: 'Wrong password.' });
      }
      const token = crypto.randomBytes(24).toString('hex');
      sessions.set(token, Date.now() + 12 * 3600 * 1000);
      return send(res, 200, { token });
    }
    if (route === 'POST /api/admin/logout') {
      const h = req.headers['authorization'] || ''; sessions.delete(h.startsWith('Bearer ') ? h.slice(7) : '');
      return send(res, 200, { ok: true });
    }
    if (route === 'GET /api/admin/data') {
      if (!adminOk(req)) return send(res, 401, { error: 'Please log in.' });
      return send(res, 200, adminData());
    }
    return send(res, 404, { error: 'Not found.' });
  } catch (e) {
    return send(res, 400, { error: 'Bad request.' });
  }
}

/* ---------------- static files ---------------- */
function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname);
  if (p === '/admin') p = '/admin.html';
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    res.end(data);
  });
}

http.createServer((req, res) => {
  let url;
  try { url = new URL(req.url, 'http://x'); } catch (e) { res.writeHead(400); return res.end(); }
  if (url.pathname.startsWith('/api/')) return api(req, res, url);
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  serveStatic(req, res, url);
}).listen(PORT, '0.0.0.0', () => {
  console.log('\n  CAMPUS QUEST is running');
  console.log('  Players : http://localhost:' + PORT);
  console.log('  Admin   : http://localhost:' + PORT + '/admin');
  for (const list of Object.values(os.networkInterfaces()))
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) console.log('  On the lab network: http://' + a.address + ':' + PORT);
  if (DEFAULT_PASSWORD) console.log('\n  !! The admin password is still the default (admin@123). Change it in config.json before the event.');
  console.log('');
});
