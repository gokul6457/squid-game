/*
 * Campus Quest server - no extra packages needed, only Node.js (v16 or newer).
 *   Start:   node server.js            (then open http://localhost:4000)
 *   Players: http://<this-computer-ip>:4000        Admin portal: http://<this-computer-ip>:4000/admin
 * Data is kept in data/db.json.  Admin password: config.json  ("adminPassword")  or the ADMIN_PASSWORD environment variable.
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { promisify } = require('util');
const { DatabaseSync } = require('node:sqlite');

const PORT = parseInt(process.env.PORT || '4000', 10);
const MAX_GAME_SECONDS = 20 * 60;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'campus-quest.sqlite');
const LEGACY_DB_FILE = path.join(DATA_DIR, 'db.json');

let config = {};
try { config = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8')); } catch (e) { /* optional */ }
const ADMIN_PASSWORD = String(process.env.ADMIN_PASSWORD || config.adminPassword || 'admin@123');
const DEFAULT_PASSWORD = ADMIN_PASSWORD === 'admin@123';

/* ---------------- SQLite storage ---------------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
const sql = new DatabaseSync(DB_FILE);
sql.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
sql.exec(`CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  salt TEXT NOT NULL, password_hash TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS participants (
  id TEXT PRIMARY KEY, account_id TEXT REFERENCES accounts(id), name TEXT NOT NULL,
  roll_no TEXT NOT NULL, team TEXT NOT NULL, registered_at INTEGER NOT NULL,
  started_at INTEGER, finished_at INTEGER, score INTEGER NOT NULL DEFAULT 0,
  right_count INTEGER NOT NULL DEFAULT 0, wrong_count INTEGER NOT NULL DEFAULT 0,
  seconds INTEGER NOT NULL DEFAULT 0, session_key TEXT, heartbeat_at INTEGER
);
CREATE INDEX IF NOT EXISTS participant_team ON participants(team COLLATE NOCASE);`);
// Migrate databases created by older Campus Quest builds.
for (const [column, type] of [['session_key', 'TEXT'], ['heartbeat_at', 'INTEGER']]) {
  try { sql.exec(`ALTER TABLE participants ADD COLUMN ${column} ${type}`); } catch (e) {
    if (!String(e.message).includes('duplicate column name')) throw e;
  }
}
const accountRows = sql.prepare('SELECT * FROM accounts').all();
const participantRows = sql.prepare('SELECT * FROM participants').all();
let db = {
  accounts: accountRows.map((a) => ({ id: a.id, email: a.email, salt: a.salt, passwordHash: a.password_hash, createdAt: a.created_at })),
  participants: participantRows.map((p) => ({ id: p.id, accountId: p.account_id, name: p.name, rollNo: p.roll_no, team: p.team,
    registeredAt: p.registered_at, startedAt: p.started_at, finishedAt: p.finished_at, score: p.score, right: p.right_count, wrong: p.wrong_count, seconds: p.seconds,
    sessionKey: p.session_key || null, heartbeatAt: p.heartbeat_at || null }))
};
if (db.participants.length === 0 && db.accounts.length === 0 && fs.existsSync(LEGACY_DB_FILE)) {
  try {
    const legacy = JSON.parse(fs.readFileSync(LEGACY_DB_FILE, 'utf8'));
    if (Array.isArray(legacy.accounts)) db.accounts = legacy.accounts;
    if (Array.isArray(legacy.participants)) db.participants = legacy.participants;
    save();
  } catch (e) { console.error('Could not import legacy data/db.json:', e.message); }
}
function save() {
  try {
    sql.exec('BEGIN IMMEDIATE');
    const insertAccount = sql.prepare(`INSERT INTO accounts(id,email,salt,password_hash,created_at) VALUES(?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET email=excluded.email,salt=excluded.salt,password_hash=excluded.password_hash,created_at=excluded.created_at`);
    const insertParticipant = sql.prepare(`INSERT INTO participants(id,account_id,name,roll_no,team,registered_at,started_at,finished_at,score,right_count,wrong_count,seconds,session_key,heartbeat_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
      ON CONFLICT(id) DO UPDATE SET account_id=excluded.account_id,name=excluded.name,roll_no=excluded.roll_no,team=excluded.team,
      registered_at=excluded.registered_at,started_at=excluded.started_at,finished_at=excluded.finished_at,score=excluded.score,
      right_count=excluded.right_count,wrong_count=excluded.wrong_count,seconds=excluded.seconds,session_key=excluded.session_key,heartbeat_at=excluded.heartbeat_at`);
    const accountIds = new Set(db.accounts.map((a) => a.id));
    const participantIds = new Set(db.participants.map((p) => p.id));
    const oldAccounts = sql.prepare('SELECT id FROM accounts').all();
    const oldParticipants = sql.prepare('SELECT id FROM participants').all();
    for (const a of db.accounts) insertAccount.run(a.id, a.email, a.salt, a.passwordHash, a.createdAt);
    for (const p of db.participants) insertParticipant.run(p.id, accountIds.has(p.accountId) ? p.accountId : null, p.name, p.rollNo, p.team,
      p.registeredAt, p.startedAt || null, p.finishedAt || null, p.score || 0, p.right || 0, p.wrong || 0, p.seconds || 0, p.sessionKey || null, p.heartbeatAt || null);
    for (const p of oldParticipants) if (!participantIds.has(p.id)) sql.prepare('DELETE FROM participants WHERE id=?').run(p.id);
    for (const a of oldAccounts) if (!accountIds.has(a.id)) sql.prepare('DELETE FROM accounts WHERE id=?').run(a.id);
    sql.exec('COMMIT');
  } catch (e) {
    try { sql.exec('ROLLBACK'); } catch (_) { /* transaction may not have started */ }
    console.error('could not save database:', e.message);
    throw e;
  }
}

/* ---------------- helpers ---------------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.wasm': 'application/wasm', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' };

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 20000) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(new Error('bad json')); } });
    req.on('error', reject);
  });
}
const clean = (s, max) => String(s == null ? '' : s).replace(/[\u0000-\u001f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
const norm = (s) => s.toLowerCase();
function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest(), hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}
function publicView(p) { return { id: p.id, name: p.name, rollNo: p.rollNo, team: p.team }; }

/* ---------------- admin sessions ---------------- */
const sessions = new Map();               // token -> expiry
const playerSessions = new Map();          // token -> { accountId, expiry }
const failures = new Map();               // ip -> [timestamps]
function clientIp(req) { return req.socket.remoteAddress || '?'; }
function tooManyFailures(ip) {
  const now = Date.now(), list = (failures.get(ip) || []).filter((t) => now - t < 5 * 60 * 1000);
  failures.set(ip, list); return list.length >= 5;
}
function adminOk(req) {
  const h = req.headers['authorization'] || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  const exp = sessions.get(token);
  if (!exp) return false;
  if (exp < Date.now()) { sessions.delete(token); return false; }
  return true;
}
function playerAccount(req) {
  const h = req.headers['authorization'] || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  const session = playerSessions.get(token);
  if (!session || session.expiry < Date.now()) { playerSessions.delete(token); return null; }
  return session.accountId;
}
function issuePlayerSession(accountId) {
  const token = crypto.randomBytes(32).toString('hex');
  playerSessions.set(token, { accountId, expiry: Date.now() + 7 * 24 * 3600 * 1000 });
  return token;
}
const pbkdf2 = promisify(crypto.pbkdf2);
async function passwordHash(password, salt) {
  return (await pbkdf2(password, salt, 180000, 32, 'sha256')).toString('hex');
}

/* ---------------- results ---------------- */
function adminData() {
  const all = db.participants;
  const accountFor = (p) => db.accounts.find((a) => a.id === p.accountId) || null;
  const emailFor = (p) => (accountFor(p) || {}).email || p.name || '';
  const finished = all.filter((p) => p.finishedAt);
  const individuals = finished.slice().sort((a, b) => b.score - a.score || a.seconds - b.seconds)
    .map((p, i) => ({ rank: i + 1, email: emailFor(p), team: p.team, score: p.score, right: p.right, wrong: p.wrong, seconds: p.seconds }));
  const groups = new Map();
  for (const p of all) {
    const k = norm(p.team);
    if (!groups.has(k)) groups.set(k, { team: p.team, members: [] });
    groups.get(k).members.push(p);
  }
  const teams = [];
  for (const g of groups.values()) {
    const fin = g.members.filter((m) => m.finishedAt);
    const total = fin.reduce((s, m) => s + m.score, 0), secs = fin.reduce((s, m) => s + m.seconds, 0);
    teams.push({ team: g.team, registered: g.members.length, finished: fin.length, totalScore: total,
      totalRight: fin.reduce((s, m) => s + (m.right || 0), 0), totalWrong: fin.reduce((s, m) => s + (m.wrong || 0), 0),
      avgScore: fin.length ? Math.round(total / fin.length * 10) / 10 : 0, totalSeconds: secs,
      avgSeconds: fin.length ? Math.round(secs / fin.length) : 0, members: g.members.map((m) => emailFor(m)) });
  }
  teams.sort((a, b) => (b.finished > 0) - (a.finished > 0) || b.avgScore - a.avgScore || a.avgSeconds - b.avgSeconds || a.team.localeCompare(b.team));
  let r = 0; teams.forEach((t) => { t.rank = t.finished ? ++r : null; });
  const participants = all.slice().sort((a, b) => a.registeredAt - b.registeredAt).map((p) => ({
    id: p.id, email: emailFor(p), passwordSet: Boolean(accountFor(p)), team: p.team, registeredAt: p.registeredAt,
    status: p.finishedAt ? 'Finished' : (p.startedAt ? 'Playing' : 'Registered'),
    right: p.right || 0, wrong: p.wrong || 0, score: p.score || 0,
    seconds: p.finishedAt ? p.seconds : (p.startedAt ? Math.max(0, Math.floor((Date.now() - p.startedAt) / 1000)) : 0) }));
  return { apiVersion: 2, generatedAt: Date.now(), summary: { registered: all.length, playing: participants.filter((p) => p.status === 'Playing').length, finished: finished.length, teams: teams.length },
      participants, individuals, teams };
}

/* ---------------- API ---------------- */
async function api(req, res, url) {
  const route = req.method + ' ' + url.pathname;
  try {
    if (route === 'GET /api/teams') {
      return send(res, 200, { teams: [...new Set(db.participants.map((p) => p.team))].sort() });
    }
    if (route === 'POST /api/account/register' || route === 'POST /api/account/login' || route === 'POST /api/account/continue') {
      const ip = clientIp(req);
      if (tooManyFailures(ip)) return send(res, 429, { error: 'Too many attempts. Please wait 5 minutes.' });
      const b = await readBody(req);
      const email = clean(b.email, 254).toLowerCase();
      const password = String(b.password || '');
      const combined = route === 'POST /api/account/continue';
      const registering = route === 'POST /api/account/register';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res, 400, { error: 'Enter a valid email address.' });
      if (password.length < 8 || password.length > 128) return send(res, 400, { error: 'Password must be 8 to 128 characters.' });
      const teamIn = (combined || registering) ? clean(b.team, 40) : '';
      if (combined && !teamIn) return send(res, 400, { error: 'Enter your team name.' });
      let account = db.accounts.find((a) => a.email === email);
      if (registering && account) {
        if (!safeEqual(await passwordHash(password, account.salt), account.passwordHash))
          return send(res, 409, { error: 'This email already has an account. Use the correct password to finish registration, or choose Sign in.' });
      } else if (route.endsWith('/register') || (combined && !account)) {
        const salt = crypto.randomBytes(16).toString('hex');
        account = { id: crypto.randomBytes(12).toString('hex'), email, salt, passwordHash: await passwordHash(password, salt), createdAt: Date.now() };
        db.accounts.push(account); save();
      } else if (!account || !safeEqual(await passwordHash(password, account.salt), account.passwordHash)) {
        failures.get(ip).push(Date.now());
        return send(res, 401, { error: 'Email or password is incorrect.' });
      }
      if (registering && teamIn) {
        if (db.participants.some((p) => p.accountId === account.id))
          return send(res, 409, { error: 'This account is already registered. Choose Sign in to continue.' });
        const existingTeam = db.participants.find((p) => norm(p.team) === norm(teamIn));
        const team = existingTeam ? existingTeam.team : teamIn;
        const participant = { id: crypto.randomBytes(12).toString('hex'), accountId: account.id, name: account.email, rollNo: account.email,
          team, registeredAt: Date.now(), startedAt: null, finishedAt: null, score: 0, right: 0, wrong: 0, seconds: 0, sessionKey: null, heartbeatAt: null };
        db.participants.push(participant);
        save();
        return send(res, 200, { registered: true, email: account.email });
      }
      if (combined) {
        const old = db.participants.find((p) => p.accountId === account.id);
        if (old && old.finishedAt) return send(res, 409, { error: 'This account has already completed the game.' });
        const existingTeam = db.participants.find((p) => norm(p.team) === norm(teamIn));
        const team = old ? old.team : (existingTeam ? existingTeam.team : teamIn);
        let participant = old;
        if (!participant) {
          participant = { id: crypto.randomBytes(12).toString('hex'), accountId: account.id, name: account.email, rollNo: account.email,
            team, registeredAt: Date.now(), startedAt: null, finishedAt: null, score: 0, right: 0, wrong: 0, seconds: 0, sessionKey: null, heartbeatAt: null };
          db.participants.push(participant);
          save();
        }
        const token = issuePlayerSession(account.id);
        return send(res, 200, { token, email: account.email, participant: publicView(participant) });
      }
      const token = issuePlayerSession(account.id);
      return send(res, 200, { token, email: account.email });
    }
    if (route === 'GET /api/player/me') {
      const accountId = playerAccount(req);
      if (!accountId) return send(res, 401, { error: 'Please sign in again.' });
      const participant = db.participants.find((p) => p.accountId === accountId && !p.finishedAt)
        || db.participants.find((p) => p.accountId === accountId);
      if (!participant) return send(res, 409, { error: 'This account is not registered for the game. Choose Register first.' });
      if (participant.finishedAt) return send(res, 409, { error: 'This account has already completed the game.' });
      return send(res, 200, { participant: publicView(participant) });
    }
    if (route === 'POST /api/account/logout') {
      const h = req.headers['authorization'] || '';
      playerSessions.delete(h.startsWith('Bearer ') ? h.slice(7) : '');
      return send(res, 200, { ok: true });
    }
    if (route === 'POST /api/register') {
      const accountId = playerAccount(req);
      if (!accountId) return send(res, 401, { error: 'Sign in or create an account first.' });
      const b = await readBody(req);
      const name = clean(b.name, 60), rollNo = clean(b.rollNo, 30), teamIn = clean(b.team, 40);
      if (name.length < 2) return send(res, 400, { error: 'Please enter your full name.' });
      if (!rollNo) return send(res, 400, { error: 'Please enter your register number.' });
      if (!teamIn) return send(res, 400, { error: 'Please enter your team name.' });
      const existingTeam = db.participants.find((p) => norm(p.team) === norm(teamIn));
      const team = existingTeam ? existingTeam.team : teamIn;
      const old = db.participants.find((p) => p.accountId === accountId && norm(p.rollNo) === norm(rollNo));
      if (old) {
        if (old.finishedAt) return send(res, 409, { error: 'This register number has already completed the game. Each student can play once.' });
        return send(res, 200, { participant: publicView(old), resumed: true });       // not finished yet: let them continue
      }
      const usedRoll = db.participants.find((p) => norm(p.rollNo) === norm(rollNo));
      if (usedRoll) return send(res, 409, { error: 'This register number is already linked to another account. Please sign in with the account used for this student.' });
      const p = { id: crypto.randomBytes(12).toString('hex'), accountId, name, rollNo, team, registeredAt: Date.now(), startedAt: null, finishedAt: null, score: 0, right: 0, wrong: 0, seconds: 0 };
      db.participants.push(p); save();
      return send(res, 200, { participant: publicView(p) });
    }
    if (route === 'POST /api/start') {
      const accountId = playerAccount(req);
      if (!accountId) return send(res, 401, { error: 'Please sign in again.' });
      const b = await readBody(req);
      const p = db.participants.find((x) => x.id === b.id && x.accountId === accountId);
      if (!p) return send(res, 404, { error: 'Unknown player.' });
      if (p.finishedAt) return send(res, 409, { error: 'Already finished.' });
      const sessionKey = clean(b.sessionKey, 80);
      if (!sessionKey) return send(res, 400, { error: 'Missing game session key.' });
      const now = Date.now(), leaseMs = 45000;
      const otherActive = db.participants.find((x) => x.accountId === accountId && x.id !== p.id && !x.finishedAt && x.sessionKey && x.heartbeatAt && now - x.heartbeatAt < leaseMs);
      if (otherActive) return send(res, 409, { error: 'This account already has a game open on another tab or computer.' });
      if (p.sessionKey && p.sessionKey !== sessionKey && p.heartbeatAt && now - p.heartbeatAt < leaseMs)
        return send(res, 409, { error: 'This game is already open on another tab or computer.' });
      p.startedAt = p.startedAt || now; p.sessionKey = sessionKey; p.heartbeatAt = now; save();
      return send(res, 200, { ok: true });
    }
    if (route === 'POST /api/heartbeat') {
      const accountId = playerAccount(req);
      if (!accountId) return send(res, 401, { error: 'Please sign in again.' });
      const b = await readBody(req);
      const p = db.participants.find((x) => x.id === b.id && x.accountId === accountId);
      if (!p) return send(res, 404, { error: 'Unknown player.' });
      if (p.finishedAt || !p.sessionKey || p.sessionKey !== clean(b.sessionKey, 80) || !p.heartbeatAt || Date.now() - p.heartbeatAt >= 45000)
        return send(res, 409, { error: 'This game session expired or is active on another tab/computer.' });
      p.heartbeatAt = Date.now(); save();
      return send(res, 200, { ok: true });
    }
    if (route === 'POST /api/submit') {
      const accountId = playerAccount(req);
      if (!accountId) return send(res, 401, { error: 'Please sign in again.' });
      const b = await readBody(req);
      const p = db.participants.find((x) => x.id === b.id && x.accountId === accountId);
      if (!p) return send(res, 404, { error: 'Unknown player.' });
      if (p.finishedAt) return send(res, 409, { error: 'Result already saved.', result: { score: p.score, right: p.right, wrong: p.wrong, seconds: p.seconds } });
      if (!p.sessionKey || p.sessionKey !== clean(b.sessionKey, 80)) return send(res, 409, { error: 'This game session is not active on this tab/computer.' });
      const serverElapsed = p.startedAt ? Math.floor((Date.now() - p.startedAt) / 1000) : 0;
      const timedOut = serverElapsed >= MAX_GAME_SECONDS;
      const right = timedOut ? 0 : Math.floor(Number(b.right));
      const wrong = timedOut ? 0 : Math.floor(Number(b.wrong));
      const clientSecs = timedOut ? MAX_GAME_SECONDS : Math.floor(Number(b.seconds));
      if (!(right >= 0 && right <= 10 && wrong >= 0 && wrong <= 10 && clientSecs >= 0)) return send(res, 400, { error: 'Invalid result.' });
      let seconds = Math.min(clientSecs, MAX_GAME_SECONDS);
      if (p.startedAt) {                                    // do not trust the browser's clock too much
        const serverSecs = Math.min(MAX_GAME_SECONDS, Math.round((Date.now() - p.startedAt) / 1000));
        if (Math.abs(serverSecs - seconds) > 10) seconds = serverSecs;
      }
      p.right = right; p.wrong = wrong; p.score = Math.max(0, (right - wrong) * 10); p.seconds = seconds; p.finishedAt = Date.now(); p.heartbeatAt = null;
      save();
      return send(res, 200, { ok: true, result: { score: p.score, right: p.right, wrong: p.wrong, seconds: p.seconds } });
    }
    if (route === 'POST /api/admin/login') {
      const ip = clientIp(req);
      if (tooManyFailures(ip)) return send(res, 429, { error: 'Too many wrong attempts. Please wait 5 minutes.' });
      const b = await readBody(req);
      if (!safeEqual(b.password || '', ADMIN_PASSWORD)) {
        failures.get(ip).push(Date.now());
        return send(res, 401, { error: 'Wrong password.' });
      }
      const token = crypto.randomBytes(24).toString('hex');
      sessions.set(token, Date.now() + 12 * 3600 * 1000);
      return send(res, 200, { token });
    }
    if (route === 'POST /api/admin/logout') {
      const h = req.headers['authorization'] || ''; sessions.delete(h.startsWith('Bearer ') ? h.slice(7) : '');
      return send(res, 200, { ok: true });
    }
    if (route === 'GET /api/admin/data') {
      if (!adminOk(req)) return send(res, 401, { error: 'Please log in.' });
      return send(res, 200, adminData());
    }
    if (route === 'POST /api/admin/reset-password') {
      if (!adminOk(req)) return send(res, 401, { error: 'Please log in.' });
      const b = await readBody(req), participantId = clean(b.participantId, 80);
      const participant = db.participants.find((p) => p.id === participantId);
      if (!participant || !participant.accountId) return send(res, 404, { error: 'This player has no linked account.' });
      const account = db.accounts.find((a) => a.id === participant.accountId);
      if (!account) return send(res, 404, { error: 'Player account was not found.' });
      const newPassword = crypto.randomBytes(9).toString('base64url');
      const previous = { salt: account.salt, passwordHash: account.passwordHash };
      const previousSessions = [...playerSessions.entries()];
      const previousPlayerLeases = db.participants.filter((p) => p.accountId === account.id)
        .map((p) => ({ p, sessionKey: p.sessionKey, heartbeatAt: p.heartbeatAt }));
      account.salt = crypto.randomBytes(16).toString('hex');
      account.passwordHash = await passwordHash(newPassword, account.salt);
      for (const [token, session] of playerSessions) if (session.accountId === account.id) playerSessions.delete(token);
      for (const p of db.participants) if (p.accountId === account.id) { p.sessionKey = null; p.heartbeatAt = null; }
      try { save(); } catch (e) {
        account.salt = previous.salt; account.passwordHash = previous.passwordHash;
        playerSessions.clear(); for (const [token, session] of previousSessions) playerSessions.set(token, session);
        for (const lease of previousPlayerLeases) { lease.p.sessionKey = lease.sessionKey; lease.p.heartbeatAt = lease.heartbeatAt; }
        throw e;
      }
      return send(res, 200, { ok: true, newPassword });
    }
    if (route === 'POST /api/admin/remove-player') {
      if (!adminOk(req)) return send(res, 401, { error: 'Please log in.' });
      const b = await readBody(req), participantId = clean(b.participantId, 80);
      const target = db.participants.find((p) => p.id === participantId);
      if (!target) return send(res, 404, { error: 'Player was not found.' });
      const previousParticipants = db.participants, previousAccounts = db.accounts;
      const accountId = target.accountId;
      db.participants = db.participants.filter((p) => p.id !== participantId);
      if (accountId && !db.participants.some((p) => p.accountId === accountId))
        db.accounts = db.accounts.filter((a) => a.id !== accountId);
      try { save(); } catch (e) { db.participants = previousParticipants; db.accounts = previousAccounts; throw e; }
      if (accountId && !db.accounts.some((a) => a.id === accountId)) {
        for (const [token, session] of playerSessions) if (session.accountId === accountId) playerSessions.delete(token);
      }
      return send(res, 200, { ok: true });
    }
    return send(res, 404, { error: 'Not found.' });
  } catch (e) {
    console.error('API request failed:', e.message);
    return send(res, 500, { error: 'Unable to process the request. Please retry.' });
  }
}

/* ---------------- static files ---------------- */
function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname);
  if (p === '/admin') p = '/admin.html';
  if (p === '/') p = '/index.html';
  // Team URLs (for example /google) are friendly entry URLs for the same game app.
  if (/^\/[^/]+$/.test(p) && !path.extname(p)) p = '/index.html';
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    res.end(data);
  });
}

http.createServer((req, res) => {
  let url;
  try { url = new URL(req.url, 'http://x'); } catch (e) { res.writeHead(400); return res.end(); }
  if (url.pathname.startsWith('/api/')) return api(req, res, url);
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  serveStatic(req, res, url);
}).listen(PORT, '0.0.0.0', () => {
  console.log('\n  CAMPUS QUEST is running');
  console.log('  Players : http://localhost:' + PORT);
  console.log('  Admin   : http://localhost:' + PORT + '/admin');
  for (const list of Object.values(os.networkInterfaces()))
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) console.log('  On the lab network: http://' + a.address + ':' + PORT);
  if (DEFAULT_PASSWORD) console.log('\n  !! The admin password is still the default (admin@123). Change it in config.json before the event.');
  console.log('');
});
