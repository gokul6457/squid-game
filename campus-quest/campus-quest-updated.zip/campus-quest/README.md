# Campus Quest

Campus Quest is a browser game with independent player accounts and a staff results portal. The game is now a beginner debugging challenge: players find 20 short Python, C and Java snippets, identify the 10 valid ones, and submit them. It uses Node.js and a local SQLite database; it does not need a hosted service for a single-server LAN event. By default it runs at `http://localhost:4000`; LAN players use the address printed by `start.bat`, on port 4000.

## Run on Windows

1. Install Node.js 22.13 or newer.
2. Extract this ZIP, open the extracted `campus-quest` folder, and double-click `start.bat` (or run `node server.js`).
3. Keep the server window running. Players on the same network open the `On the lab network` address shown there. Staff open that address with `/admin` added.
4. Before the event, change `adminPassword` in `config.json` and restart the server. Staff can open the admin portal directly at `/admin`; its link is not shown on the player page.

## Player accounts

Players first choose **Sign in** or **Register**. Registration asks for team name, email, and password; afterward, the player returns to Sign in and logs in to start the game. Passwords are stored as salted PBKDF2 hashes. Each account gets one player registration and can play once. The game requests browser full screen on the first game interaction. Leaving full screen, switching tabs, or leaving the page ends and saves the attempt. Browsers still allow users to open tabs or exit full screen; this game detects that and forfeits the attempt. The server grants one active game session per account across tabs and computers and expires an unexpectedly disconnected session after 45 seconds without a heartbeat.

After player registration, the address changes to a readable team path (for example, `/google` or `/google-team`) and the browser tab title shows the team. Share the same server address with everyone; the path is a friendly label, not a separate server or security boundary. Game sessions and results still go through the same backend and database, where the account lock prevents the same account from playing simultaneously on another tab or computer.

After joining, the address changes to a readable team path (for example, `/google`). The path is a friendly label, not a separate server or security boundary. The sign-in token is kept in that browser's local storage. For a shared computer, use a separate browser profile or clear the previous player's session before the next person signs in. Accounts and scores are stored on the server.

## Data and backups

The server uses Node.js's built-in SQLite support; no separate SQL server is required. It creates `data/campus-quest.sqlite` on first run and writes accounts and results there. In the extracted project, the full path is `<project folder>\data\campus-quest.sqlite`. SQLite uses write-ahead logging and indexes the account and team lookups. Back up the database by copying the `data` folder while the server is stopped. To reset an event, stop the server and remove `data/campus-quest.sqlite` and its `-wal`/`-shm` files. Existing `data/db.json` files are imported on first launch when the SQLite database is empty.

SQLite is suitable for a single app server and a small LAN event. For multiple app servers, move storage to PostgreSQL and use HTTPS with a production process manager; this package is not a production high-availability setup. 100 simultaneous players can still be limited by the host computer, LAN, and each player's device. The game renders locally in each browser, so the server mainly handles sign-in and small result requests.

## Admin portal

The `/admin` page uses the password in `config.json` (or `ADMIN_PASSWORD` environment variable). It shows registrations, results, and team rankings. On the Registrations tab, staff can remove a player; this deletes that player's registration, saved result, and account when no other player record uses it. Keep the portal private to staff and change the sample password before use.

## Files

- `server.js`: HTTP server, account authentication, game API, and admin API.
- `public/`: game website and browser assets, including the compiled WebAssembly game.
- `game-src/`: game source and web build scripts.
- `data/`: SQLite runtime database, created on first launch (not included in the ZIP).
