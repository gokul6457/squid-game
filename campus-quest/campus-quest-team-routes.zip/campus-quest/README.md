# Campus Quest

Campus Quest is a browser game with independent player accounts and a staff results portal. It uses Node.js and a local SQLite database; it does not need a hosted service for a single-server LAN event.

## Run on Windows

1. Install Node.js 22.13 or newer.
2. Extract this ZIP, open the extracted `campus-quest` folder, and double-click `start.bat` (or run `node server.js`).
3. Keep the server window running. Players on the same network open the `On the lab network` address shown there. Staff open that address with `/admin` added.
4. Before the event, change `adminPassword` in `config.json` and restart the server. Do not expose the default password to players.

## Player accounts

Each player creates an account with their own email and password, then enters their name, register number, and team. Passwords are stored as salted PBKDF2 hashes. Email addresses and register numbers are unique. A player can resume an unfinished entry from the same account; a completed entry cannot be replayed. The server grants one active game session per account across tabs and computers. It renews the lock every 15 seconds and releases a disconnected session after 45 seconds without a heartbeat. If a player changes computers after a disconnect, wait up to 45 seconds and sign in with the same account.

After player registration, the address changes to a readable team path (for example, `/google` or `/google-team`) and the browser tab title shows the team. Share the same server address with everyone; the path is a friendly label, not a separate server or security boundary. Game sessions and results still go through the same backend and database, where the account lock prevents the same account from playing simultaneously on another tab or computer.

The sign-in token is kept in that browser's local storage. Sign out before handing a shared computer to another player. Accounts and scores are stored on the server, so players can use different computers and still sign in to the same account.

## Data and backups

The server creates `data/campus-quest.sqlite` on first run and writes accounts and results there. SQLite uses write-ahead logging and indexes the account and team lookups. Back up the database by copying the `data` folder while the server is stopped. To reset an event, stop the server and remove `data/campus-quest.sqlite` and its `-wal`/`-shm` files. Existing `data/db.json` files are imported on first launch when the SQLite database is empty.

SQLite is suitable for a single app server and a small LAN event. For multiple app servers, move storage to PostgreSQL and use HTTPS with a production process manager; this package is not a production high-availability setup. 100 simultaneous players can still be limited by the host computer, LAN, and each player's device. The game renders locally in each browser, so the server mainly handles sign-in and small result requests.

## Admin portal

The `/admin` page uses the password in `config.json` (or `ADMIN_PASSWORD` environment variable). It shows registrations, results, and team rankings. Keep the portal private to staff and change the sample password before use.

## Files

- `server.js`: HTTP server, account authentication, game API, and admin API.
- `public/`: game website and browser assets, including the compiled WebAssembly game.
- `game-src/`: game source and web build scripts.
- `data/`: SQLite runtime database, created on first launch (not included in the ZIP).
